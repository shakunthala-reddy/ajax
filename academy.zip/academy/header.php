<!DOCTYPE html>
<html 
<?php $lang_toggle = get_field('is_hindi') ?>

<?php 
if($lang_toggle){
echo 'lang="hi-IN"';
}else{
echo 'lang="en-US"';
} 
?>

>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#126BBF">
    <link rel="shortcut icon" href="<?php the_field('favicon', 'option'); ?>" type="image/x-icon">
    <!-- GTM Updated -->
  

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> id="overchal">
