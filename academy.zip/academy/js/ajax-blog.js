function getblogdetails () {
//    alert('hi');
    $("#sub-brand-dropdownlist").on("change", function () {
   // alert('hi');
    var subbrand_id = this.value;
    // alert(subbrand_id);
    jQuery.ajax({
        type: 'POST',
        url: WP_URLS.ajaxurl,
        data: {
            action: 'get_blog_det',
            security: WP_URLS.security,
            subbrand_id: subbrand_id
        },
        success: function (response, status) {
            //console.log(response);
            $('#get-all-posts').html(response);
           // $('sub-brand-dropdown').show().response;
        }

    });
   
});
}

$(document).ready(function () {
getblogdetails ()
})