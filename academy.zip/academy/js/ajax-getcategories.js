function getcatsub () {
        $("#brand-dropdown").on("change", function () {
        var brand_id = this.value;
        //alert(brand_id);
        jQuery.ajax({
            type: 'POST',
            url: WP_URLS.ajaxurl,
            data: {
                action: 'get_cat_sub',
                security: WP_URLS.security,
                brand_id: brand_id
            },
            success: function (response, status) {
                //console.log(response);
                $('.sub-brand-dropdown-get').html(response);
               // $('sub-brand-dropdown').show().response;
            }

        });
       
    });
}

$(document).ready(function () {
    getcatsub ()
 })