<?php
/* Template Name: Home page*/
get_header();
?>
<h1>Getting Subcategory</h1>
<?php

  //  $category_bucket = array();
    if( $terms = get_terms( array(
    'taxonomy' => 'category', // to make it simple I use default categories
    'orderby' => 'name',
    'parent' => 0
) ) ) : 
	// if categories exist, display the dropdown

  echo '<div>';
  echo "Category";
	echo '<select name="categoryfilter" id="brand-dropdown"><option value="">Select category...</option>';
  $category_bucket = array();
	foreach ( $terms as $term ) :
        $category_bucket [] = $term->term_id;
        // $parentlist = implode(', ', $category_bucket);
        // print_r($parentlist);
		echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as an option value
	endforeach;
	echo '</select>';
  echo '</div>';
endif;
?>
<div class="sub-brand-dropdown-get"></div>


<h1>Getting posts</h1>
<?php

// $parentlist = implode(', ', $category_bucket);
// print_r($parentlist);
if( $terms = get_terms( array(
  'taxonomy' => 'category', // to make it simple I use default categories
  'orderby' => 'name',
  'child_of' => 0
  // 'child_of' => array($parentlist)
) ) ) : 
// if categories exist, display the dropdown

echo '<div>';
echo "Subcateogroy";
echo '<select name="categoryfilter" id="sub-brand-dropdownlist"><option value="">Select category...</option>';
foreach ( $terms as $term ) :
      $category_bucket [] = $term->term_id;
  echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as an option value
endforeach;
echo '</select>';
echo '</div>';
endif;

?>
<div id="get-all-posts"></div>
<?php get_footer();?>