<?php 
/*
* Template Name: demo
*/
get_header();
?>
<h3>Filter recepies:</h3>

<div>
<p>Select vegetables</p>
<label><input type="checkbox" class="vegetables" value="potato"> Potato</label><br>
<label><input type="checkbox" class="vegetables" value="onion"> Onion</label><br>
<label><input type="checkbox" class="vegetables" value="tomato"> Tomato</label><br>
</div>

<div>
<p>Select seasoning</p>
<label><input type="checkbox" class="seasoning" value="salt"> Salt</label><br>
<label><input type="checkbox" class="seasoning" value="pepper"> Pepper</label><br>
<label><input type="checkbox" class="seasoning" value="chilli"> Chilli Flakes</label><br>
</div>

<?php get_footer(); ?>

<script>
$(function() {

	$(".vegetables, .seasoning").on("change", function() {
    	var hash = $(".vegetables:checked, .seasoning:checked").map(function() {
        	return this.value;
        }).toArray();
        hash = hash.join("&");
        location.hash = hash;
     });
    
    // if (location.hash !== "") {
    // 	var hash = location.hash.substr(1).split("|");
    //     hash.forEach(function(value) {
    //     	$("input[value=" + value + "]").prop("checked", true);
    //     });
    // }
});
</script>