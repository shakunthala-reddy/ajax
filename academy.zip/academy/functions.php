<?php
// general theme helpers
require_once(get_template_directory() . '/inc/enqueue-scripts.php');



function myTheme_Support(){
	//Title (auto added when wp_head() is added)
	add_theme_support('title-tag');
	//Logo (the_custom_logo())
	add_theme_support( 'custom-logo', array(
	    'height'      => 100,
	    'width'       => 400,
	    'flex-height' => true,
	    'flex-width'  => true,
	    'header-text' => array( 'site-title', 'site-description' ),
	) );
	//Thumbnail
	add_theme_support('post-thumbnails');
	// post formats
    add_theme_support( 'post-formats',
    	array('aside','image','gallery','video','audio','link','quote','status')
    );
	// Set up the WordPress core custom background feature.(auto added when wp_head() is added)
	add_theme_support(
		'custom-background',
		apply_filters(
			'custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);
	//Header BG  (img src="echo get_header_image())
	add_theme_support( 'custom-header' );
	//html5
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);
	//Feed Link
	add_theme_support( 'automatic-feed-links' );
}
add_action('after_setup_theme', 'myTheme_Support');

require get_template_directory() . '/inc/ajax-get-cat.php';
require get_template_directory() . '/inc/ajax-blog.php';

