<?php

add_action('wp_ajax_nopriv_get_cat_sub', 'get_cat_sub');
add_action('wp_ajax_get_cat_sub', 'get_cat_sub');

function get_cat_sub()
{
    $cat_id = $_POST['brand_id'];
    if( $terms = get_terms( array(
        'taxonomy' => 'category', // to make it simple I use default categories
        'orderby' => 'name',
        'parent' => $cat_id
    ) ) ) : 
    echo '</br>';
    echo "Sub Category";
        echo '<select id="sub-brand-dropdown"><option value="">Select category...</option>';
        foreach ( $terms as $term ) :
            echo '<option value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as an option value
        endforeach;
        echo '</select>';
    endif;
    die();
}

