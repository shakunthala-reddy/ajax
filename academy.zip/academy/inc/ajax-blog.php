<?php
add_action('wp_ajax_nopriv_get_blog_det', 'get_blog_det');
add_action('wp_ajax_get_blog_det', 'get_blog_det');
function get_blog_det()
{
$catid = $_POST['subbrand_id'];
$args = array(
    'post_type' => 'post',
    'orderby'=> 'post_date', 
    'order' => 'DESC',
    'posts_per_page' => -1,
    'cat' => $catid
);
$loop = new WP_Query( $args );
$i = 1;
//$catname = array();
while ( $loop->have_posts() ) : 
    $loop->the_post();
    echo '<div>';
echo "<h2>".the_title()."<h2>";
echo '</div>';
endwhile; wp_reset_postdata();
die();
}
