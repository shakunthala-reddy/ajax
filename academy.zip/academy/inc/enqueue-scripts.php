<?php
function framework_scripts()
{

    $path = get_template_directory_uri();
    $version="1.0.6";
    // Load site libs js files in footer
    //wp_deregister_script('bootstrap'); // to prevent clash with plugins calling bootstrap

    // Adding scripts file in the footer
    wp_enqueue_script('tolltip', 'https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js', array(), $version, true);
    wp_enqueue_script('mapeia-jquery', '//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', array(), $version, false);
    wp_enqueue_script('bootstrap4', '//maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array(), $version, true);
    wp_enqueue_script('pooper', '//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js', array(), $version, true);


    wp_localize_script('mapeia-main', 'WPURL', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
    ));

    
    wp_enqueue_script('get_cat_sub', $path . '/js/ajax-getcategories.js', array('mapeia-jquery'), $version, false);
    wp_localize_script('get_cat_sub', 'WP_URLS', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'security' => wp_create_nonce('load_more_posts')
    ));
    wp_enqueue_script('get_blog_det', $path . '/js/ajax-blog.js', array('mapeia-jquery'), $version, false);
    wp_localize_script('get_blog_det', 'WP_URLS', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'security' => wp_create_nonce('load_more_posts')
    ));

}

add_action('wp_enqueue_scripts', 'framework_scripts', 1000);


function framework_styles()
{
    global $wp_styles; // Call global $wp_styles variable to add conditional wrapper around ie stylesheet the WordPress way
    $path = get_template_directory_uri();
    $version="1.0.1";
    // libraries
    wp_enqueue_style('mapeiacss-bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', array(), $version);
  

    wp_enqueue_style('mapeiacss-style', get_stylesheet_uri());
}

add_action('wp_enqueue_scripts', 'framework_styles', 1000);


